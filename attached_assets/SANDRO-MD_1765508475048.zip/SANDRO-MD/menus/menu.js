
const menu = (prefix, pushname, NickDono, NomeDoBot, isChVip, sender, packname) => {
return`╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐒𝐄𝐉𝐀-𝐁𝐄𝐌-𝐕𝐈𝐍𝐃𝐎(𝐀)⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝
╭━━⪩ 愛 INFO BOT | USER 愛 ⪨━━
│🏓⃤Bot: ${NomeDoBot}
│🏓⃤Dono: ${NickDono}
│🏓⃤Usuário: *@${pushname}*
│🏓⃤Biblioteca: Baileys MD
│🏓⃤Prefixo: [${prefix}]
│🏓⃤Vip?: [${isChVip}]
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *Menus* ⪨━━━
│🏓⃤${prefix}Lojinha
│🏓⃤${prefix}menuff
│🏓⃤${prefix}Menubasico
│🏓⃤${prefix}Menudono
│🏓⃤${prefix}Menuadm
│🏓⃤${prefix}Menupremium
│🏓⃤${prefix}Efeitosimg
│🏓⃤${prefix}Logos 
│🏓⃤${prefix}Brincadeiras
│🏓⃤${prefix}Animes 
│🏓⃤${prefix}Menufig
│🏓⃤${prefix}menulink
│🏓⃤${prefix}Downloads
│🏓⃤${prefix}Menucity
│🏓⃤${prefix}Menu18
│🏓⃤${prefix}Infodono
│🏓⃤${prefix}dono
│🏓⃤${prefix}Menusemprefixo
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *CMD DE TEXTO* ⪨━━━
│🏓⃤${prefix}piadas
│🏓⃤${prefix}indiretas
│🏓⃤${prefix}ansiedade
│🏓⃤${prefix}cantadas
│🏓⃤${prefix}frasedeamor
│🏓⃤${prefix}frasecriativas
│🏓⃤${prefix}frasebonita
│🏓⃤${prefix}deboche
│🏓⃤${prefix}safadeza
│🏓⃤${prefix}raiva
│🏓⃤${prefix}motivacional
│🏓⃤${prefix}frasesdeamor
│🏓⃤${prefix}frasebonita
│🏓⃤${prefix}frasecriativas
│🏓⃤${prefix}recado
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *DIVERSOS* ⪨━━━
│🏓⃤${prefix}gptvoz (Ola tudo bem?)
│🏓⃤${prefix}rfundo (marcar-imagem)
│🏓⃤${prefix}zerotwo (oii)
│🏓⃤${prefix}imgpralink (marcar-img)
│🏓⃤${prefix}imgpralink2 (marcar-img)
│🏓⃤${prefix}ensina (90+90)
│🏓⃤${prefix}happymod (Free fire)
│🏓⃤${prefix}otakotaku (Naruto)
│🏓⃤${prefix}stalktwitter (alanzoka)
│🏓⃤${prefix}tikstalk (sr_gelado19)
│🏓⃤${prefix}instastalk (sx_sandro)
│🏓⃤${prefix}youtubetalk (SANDRO-BOT)
│🏓⃤${prefix}pais (Brasil)
│🏓⃤${prefix}dns (https://google.com)
│🏓⃤${prefix}traduzir (cat)
│🏓⃤${prefix}totext (marcar-audio)
│🏓⃤${prefix}stalkerzap (channel-link)
│🏓⃤${prefix}personagem (Naruto)
│🏓⃤${prefix}anime2 (Naruto)
│🏓⃤${prefix}movie (Moana)
│🏓⃤${prefix}movielist (Moana)
│🏓⃤${prefix}rgtinder
│🏓⃤${prefix}cat
│🏓⃤${prefix}aleatorio
│🏓⃤${prefix}dog
│🏓⃤${prefix}pokemon (pikachu)
│🏓⃤${prefix}gethtml (link site)
│🏓⃤${prefix}comprarbot
│🏓⃤${prefix}ping (velocidade)
│🏓⃤${prefix}gerarnick (sandro)
│🏓⃤${prefix}gerarnick2 (sandro)
│🏓⃤${prefix}ping2 (velocidade)
│🏓⃤${prefix}metadinha
│🏓⃤${prefix}convite (link do grupo)
│🏓⃤${prefix}calcular (13+11)
│🏓⃤${prefix}bhaskara (2x²+4x+2 = 0)
│🏓⃤${prefix}tagme
│🏓⃤${prefix}raizquadrada (√8)
│🏓⃤${prefix}dados
│🏓⃤${prefix}alugar
│🏓⃤${prefix}pinterest (anime)
│🏓⃤${prefix}pinterest2 (anime)
│🏓⃤${prefix}gtts pt (oii)
│🏓⃤${prefix}tinder
│🏓⃤${prefix}vertinder
│🏓⃤${prefix}tinyur (link)
│🏓⃤${prefix}encurtalink (link)
│🏓⃤${prefix}games (Minecraft)
│🏓⃤${prefix}tomp3 (marcar video)
│🏓⃤${prefix}simi (oii)
│🏓⃤${prefix}biografia
│🏓⃤${prefix}arma (AK47)
│🏓⃤${prefix}pegadinha
│🏓⃤${prefix}waifu
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *LOGOS* ⪨━━━
│🏓⃤${prefix}hackneon [TXT]
│🏓⃤${prefix}fpsmascote [TXT]
│🏓⃤${prefix}equipemascote [TXT]
│🏓⃤${prefix}txtquadrinhos [TXT]
│🏓⃤${prefix}ffavatar [TXT]
│🏓⃤${prefix}mascotegame [TXT]
│🏓⃤${prefix}angelglx [TXT]
│🏓⃤${prefix}gizquadro [TXT]
│🏓⃤${prefix}wingeffect [TXT]
│🏓⃤${prefix}blackpink [TXT]
│🏓⃤${prefix}girlmascote [TXT]
│🏓⃤${prefix}logogame [TXT]
│🏓⃤${prefix}cria [TXT] 
│🏓⃤${prefix}anime1 [TXT]
│🏓⃤${prefix}game [TXT]
│🏓⃤${prefix}ff2 [TXT]
│🏓⃤${prefix}anime2 [TXT]
│🏓⃤${prefix}entardecer [TXT]
│🏓⃤${prefix}dragonredn [TXT]
│🏓⃤${prefix}wolf [TXT]
│🏓⃤${prefix}anime2 [TXT]
│🏓⃤${prefix}cria anime1 [TXT]
│🏓⃤${prefix}game [TXT]
│🏓⃤${prefix}ff1 [TXT]
│🏓⃤${prefix}chufuyu [TXT]
│🏓⃤${prefix}ffgren [TXT]
│🏓⃤${prefix}ffrose [TXT]
│🏓⃤${prefix}entardecer [TXT]
│🏓⃤${prefix}indian [TXT]
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *LOGOS AV* ⪨━━━
│🏓⃤${prefix}glitch [TXT]
│🏓⃤${prefix}write [TXT]
│🏓⃤${prefix}advancedglow [TXT]
│🏓⃤${prefix}typography [TXT]
│🏓⃤${prefix}pixelglitch [TXT]
│🏓⃤${prefix}neonglitch [TXT]
│🏓⃤${prefix}flag [TXT]
│🏓⃤${prefix}flag3d [TXT]
│🏓⃤${prefix}deleting [TXT]
│🏓⃤${prefix}blackpink [TXT]
│🏓⃤${prefix}glowing [TXT]
│🏓⃤${prefix}underwater [TXT]
│🏓⃤${prefix}logomaker [TXT]
│🏓⃤${prefix}cartoon [TXT]
│🏓⃤${prefix}papercut [TXT]
│🏓⃤${prefix}watercolor [TXT]
│🏓⃤${prefix}effectclouds [TXT]
│🏓⃤${prefix}blackpinklogo [TXT]
│🏓⃤${prefix}gradient [TXT]
│🏓⃤${prefix}summerbeach [TXT]
│🏓⃤${prefix}luxurygold [TXT]
│🏓⃤${prefix}multicoloredneon [TXT]
│🏓⃤${prefix}sandsummer [TXT]
│🏓⃤${prefix}galaxywallpaper [TXT]
│🏓⃤${prefix}1917 [TXT]
│🏓⃤${prefix}makingneon [TXT]
│🏓⃤${prefix}royal [TXT]
│🏓⃤${prefix}freecreate [TXT]
│🏓⃤${prefix}galaxy [TXT]
│🏓⃤${prefix}darkgreen [TXT]
│🏓⃤${prefix}lighteffects [TXT] 
│🏓⃤${prefix}dragonball [TXT]
│🏓⃤${prefix}neondevil [TXT]
│🏓⃤${prefix}frozen [TXT]
│🏓⃤${prefix}wooden3d [TXT]
│🏓⃤${prefix}metal3d [TXT]
│🏓⃤${prefix}ligatures [TXT]
│🏓⃤${prefix}3druby [TXT]
│🏓⃤${prefix}sunset [TXT]
│🏓⃤${prefix}cemetery [TXT]
│🏓⃤${prefix}halloween [TXT]
│🏓⃤${prefix}horror [TXT]
│🏓⃤${prefix}blood [TXT]
│🏓⃤${prefix}joker [TXT]
│🏓⃤${prefix}clouds [TXT]
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *MONTAGEM* ⪨━━━
│🏓⃤${prefix}bolsonaro (marca uma imagem) 
│🏓⃤${prefix}comunismo (marca uma imagem) 
│🏓⃤${prefix}jail (marca uma imagem) 
│🏓⃤${prefix}rip (marca uma imagem) 
│🏓⃤${prefix}pixelate (marca uma imagem) 
│🏓⃤${prefix}lgbt (marca uma imagem) 
│🏓⃤${prefix}placaloli (SANDRO-MD)
│🏓⃤${prefix}captain (SANDRO/MD) 
│🏓⃤${prefix}phlogo (SANDRO/MD) 
│🏓⃤${prefix}graffitiwall (SANDRO/MD) 
│🏓⃤${prefix}deadpool (SANDRO/MD) 
│🏓⃤${prefix}blackpink (SANDRO/MD) 
│🏓⃤${prefix}vintage3d (SANDRO/MD) 
│🏓⃤${prefix}glitter (SANDRO/MD)
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *FIGURINHAS* ⪨━━━
│🏓⃤${prefix}gura
│🏓⃤${prefix}ttp (Seu texto)
│🏓⃤${prefix}Attp (Seu texto)
│🏓⃤${prefix}Attp1 (Seu texto)
│🏓⃤${prefix}Attp2 (Seu texto)
│🏓⃤${prefix}Attp3 (Seu texto)
│🏓⃤${prefix}Attp4 (Seu texto)
│🏓⃤${prefix}Attp5 (Seu texto)
│🏓⃤${prefix}Attp6 (Seu texto)
│🏓⃤${prefix}Attp7 (Seu texto)
│🏓⃤${prefix}Attp8 (Seu texto)
│🏓⃤${prefix}Attp9 (Seu texto)
│🏓⃤${prefix}figuperfil
│🏓⃤${prefix}emojimix (😍+🥰)
│🏓⃤${prefix}Fsticker (Marcar-foto)
│🏓⃤${prefix}Sticker (Marcar-foto)
│🏓⃤${prefix}Toimg (Marcar-sticker)
│🏓⃤${prefix}Togif (Marcar-sticker)
│🏓⃤${prefix}amongsticker (sandro)
│🏓⃤${prefix}figaleatoria (5)
│🏓⃤${prefix}figuraiva (5)
│🏓⃤${prefix}figuroblox (5)
│🏓⃤${prefix}figuengracada (5)
│🏓⃤${prefix}figuanimais (5)
│🏓⃤${prefix}figudesenho (5)
│🏓⃤${prefix}figubebe (5)
│🏓⃤${prefix}figucoreana (5)
│🏓⃤${prefix}figuflork (5)
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *PESQUISAR* ⪨━━━
│🏓⃤${prefix}videoporn (link-xv)
│🏓⃤${prefix}gimage (anime)
│🏓⃤${prefix}operadora (5531xxxx)
│🏓⃤${prefix}xvsearch (morena)
│🏓⃤${prefix}dorama (link)
│🏓⃤${prefix}pesquisaytb (Sandro bot)
│🏓⃤${prefix}anime (Kimetsu no Yaiba)
│🏓⃤${prefix}googlesearch (Moana)
│🏓⃤${prefix}noticias (Bolsonaro)
│🏓⃤${prefix}chatgpt (ola)
│🏓⃤${prefix}chatgpt2 (ola)
│🏓⃤${prefix}chatgpt3 (ola)
│🏓⃤${prefix}clima (Sao Paulo)
│🏓⃤${prefix}clima2 (Sao Paulo)
│🏓⃤${prefix}letramusic (mc Kevin)
│🏓⃤${prefix}aptoide (Free fire)
│🏓⃤${prefix}aptoidelink (link aptoide)
│🏓⃤${prefix}pesquisa (mc Kevin)
│🏓⃤${prefix}print (https://www.xvideos.com/)
│🏓⃤${prefix}Playstore (free fiee)
│🏓⃤${prefix}Playstore2 (Minecraft)
│🏓⃤${prefix}ytsearch (mc paiva)
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *Download* ⪨━━━
│🏓⃤${prefix}soundcloud (link)
│🏓⃤${prefix}playmix (nome)
│🏓⃤${prefix}playlist (mc paiva)
│🏓⃤${prefix}play (nome)
│🏓⃤${prefix}play1 (nome)
│🏓⃤${prefix}play2 (nome)
│🏓⃤${prefix}play3 (nome)
│🏓⃤${prefix}play4 (nome)
│🏓⃤${prefix}playvideo (nome)
│🏓⃤${prefix}facebook (link)
│🏓⃤${prefix}tiktokaudio (link)
│🏓⃤${prefix}tiktok (link)
│🏓⃤${prefix}tiktok2 (link)
│🏓⃤${prefix}tiktok3 (nome)
│🏓⃤${prefix}ytmp3 (link)
│🏓⃤${prefix}ytmp4 (link)
│🏓⃤${prefix}ytdoc (link)
│🏓⃤${prefix}ytsearch (nome)
│🏓⃤${prefix}spotify (link)
│🏓⃤${prefix}twitteraudio (link)
│🏓⃤${prefix}twittervideo (link)
│🏓⃤${prefix}Instagram (link)
│🏓⃤${prefix}Instagramaudio (link)
╰━━━━━─「愛」─━━━━━`;
};

exports.menu = menu;

const menuff = (prefix, pushname, NickDono, NomeDoBot, isChVip, sender, packname) => {
return`╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐂𝐎𝐌𝐀𝐍𝐃𝐎𝐒 𝐅𝐑𝐄𝐄 𝐅𝐈𝐑𝐄⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝
╭━━━⪩ *COMANDOS FF* ⪨━━━
│🏓⃤${prefix}ffstalk (ID)
│🏓⃤${prefix}ffinfo (ID)
│🏓⃤${prefix}ffdata (ID)
│🏓⃤${prefix}ffprime (ID)
│🏓⃤${prefix}ffbios
│🏓⃤${prefix}ffban (ID)
╰━━━━━─「愛」─━━━━━`;
};

exports.menuff = menuff;


const menubasico = (prefix, pushname, NickDono, NomeDoBot, isChVip, sender, packname) => {
return`╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐂𝐎𝐌𝐀𝐍𝐃𝐎𝐒 𝐁Á𝐒𝐈𝐂𝐎𝐒⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝
╭━━━⪩ *CMD DE TEXTO* ⪨━━━
│🏓⃤${prefix}piadas
│🏓⃤${prefix}indiretas
│🏓⃤${prefix}ansiedade
│🏓⃤${prefix}cantadas
│🏓⃤${prefix}frasedeamor
│🏓⃤${prefix}frasecriativas
│🏓⃤${prefix}frasebonita
│🏓⃤${prefix}deboche
│🏓⃤${prefix}safadeza
│🏓⃤${prefix}raiva
│🏓⃤${prefix}motivacional
│🏓⃤${prefix}frasesdeamor
│🏓⃤${prefix}frasebonita
│🏓⃤${prefix}frasecriativas
│🏓⃤${prefix}recado
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *DIVERSOS* ⪨━━━
│🏓⃤${prefix}movie (Moana)
│🏓⃤${prefix}movielist (Moana)
│🏓⃤${prefix}rgtinder
│🏓⃤${prefix}cat
│🏓⃤${prefix}aleatorio
│🏓⃤${prefix}dog
│🏓⃤${prefix}pokemon (pikachu)
│🏓⃤${prefix}gethtml (link site)
│🏓⃤${prefix}comprarbot
│🏓⃤${prefix}ping
│🏓⃤${prefix}gerarnick (sandro)
│🏓⃤${prefix}gerarnick2 (sandro)
│🏓⃤${prefix}ping2
│🏓⃤${prefix}metadinha
│🏓⃤${prefix}convite (link do grupo)
│🏓⃤${prefix}calcular (13+11)
│🏓⃤${prefix}bhaskara (2x²+4x+2 = 0)
│🏓⃤${prefix}tagme
│🏓⃤${prefix}raizquadrada (√8)
│🏓⃤${prefix}dados
│🏓⃤${prefix}alugar
│🏓⃤${prefix}pinterest (anime)
│🏓⃤${prefix}pinterest2 (anime)
│🏓⃤${prefix}gtts pt (oii)
│🏓⃤${prefix}tinder
│🏓⃤${prefix}vertinder
│🏓⃤${prefix}tinyur (link)
│🏓⃤${prefix}encurtalink (link)
│🏓⃤${prefix}games (Minecraft)
│🏓⃤${prefix}tomp3 (marcar video)
│🏓⃤${prefix}simi (oii)
│🏓⃤${prefix}biografia
│🏓⃤${prefix}arma (AK47)
│🏓⃤${prefix}pegadinha
│🏓⃤${prefix}waifu
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *FIGURINHAS* ⪨━━━
│🏓⃤${prefix}gura
│🏓⃤${prefix}ttp (Seu texto)
│🏓⃤${prefix}Attp (Seu texto)
│🏓⃤${prefix}Attp1 (Seu texto)
│🏓⃤${prefix}Attp2 (Seu texto)
│🏓⃤${prefix}Attp3 (Seu texto)
│🏓⃤${prefix}Attp4 (Seu texto)
│🏓⃤${prefix}Attp5 (Seu texto)
│🏓⃤${prefix}Attp6 (Seu texto)
│🏓⃤${prefix}Attp7 (Seu texto)
│🏓⃤${prefix}Attp8 (Seu texto)
│🏓⃤${prefix}Attp9 (Seu texto)
│🏓⃤${prefix}emojimix (😍+🥰)
│🏓⃤${prefix}Fsticker (Marcar-foto)
│🏓⃤${prefix}Sticker (Marcar-foto)
│🏓⃤${prefix}Toimg (Marcar-sticker)
│🏓⃤${prefix}Togif (Marcar-sticker)
│🏓⃤${prefix}amongsticker (sandro)
│🏓⃤${prefix}figaleatoria (5)
│🏓⃤${prefix}figuraiva (5)
│🏓⃤${prefix}figuroblox (5)
│🏓⃤${prefix}figuengracada (5)
│🏓⃤${prefix}figuanimais (5)
│🏓⃤${prefix}figudesenho (5)
│🏓⃤${prefix}figubebe (5)
│🏓⃤${prefix}figucoreana (5)
│🏓⃤${prefix}figuflork (5)
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *PESQUISAR* ⪨━━━
│🏓⃤${prefix}pesquisaytb (Sandro bot)
│🏓⃤${prefix}anime (Kimetsu no Yaiba)
│🏓⃤${prefix}googlesearch (Moana)
│🏓⃤${prefix}noticias (Bolsonaro)
│🏓⃤${prefix}chatgpt (ola)
│🏓⃤${prefix}clima (Sao Paulo)
│🏓⃤${prefix}clima2 (Sao Paulo)
│🏓⃤${prefix}letramusic (mc Kevin)
│🏓⃤${prefix}aptoide (Free fire)
│🏓⃤${prefix}aptoidelink (link aptoide)
│🏓⃤${prefix}pesquisa (mc Kevin)
│🏓⃤${prefix}print (https://www.xvideos.com/)
│🏓⃤${prefix}Playstore (free fiee)
│🏓⃤${prefix}Playstore2 (Minecraft)
│🏓⃤${prefix}ytsearch (mc paiva)
╰━━━━━─「愛」─━━━━━`;
};

exports.menubasico = menubasico;

const adms = (prefix, sender) => { 
return `​╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐂𝐎𝐌𝐀𝐍𝐃𝐎𝐒 𝐀𝐃𝐌⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝
╭═══════════════════ 
│🏓⃤${prefix}nuke (arquivar-grupo)
│🏓⃤${prefix}anotacoes
│🏓⃤${prefix}anotar (Teste|oii)
│🏓⃤${prefix}listaddi (55)
│🏓⃤${prefix}listabr
│🏓⃤${prefix}advertidos
│🏓⃤${prefix}rankddd
│🏓⃤${prefix}adverti (@)
│🏓⃤${prefix}Antiimg (1/0)
│🏓⃤${prefix}Antivideo (1/0)
│🏓⃤${prefix}Antiaudio (1/0)
│🏓⃤${prefix}Antisticker (1/0)
│🏓⃤${prefix}Antiloc (1/0)
│🏓⃤${prefix}Anticontato (1/0)
│🏓⃤${prefix}Antidoc (1/0)
│🏓⃤${prefix}Antilinkgp (1/0)
│🏓⃤${prefix}Antilinkhard (1/0)
│🏓⃤${prefix}Antifake (1/0)
│🏓⃤${prefix}Antinotas (1/0)
│🏓⃤${prefix}Anticatalogo (1/0)
│🏓⃤${prefix}Antipalavrao (1/0)
│🏓⃤${prefix}Limitecaracteres (1/0)
│🏓⃤${prefix}Bemvindo (1/0)
│🏓⃤${prefix}Bemvindo2 (1/0)
│🏓⃤${prefix}Simih (1/0)
│🏓⃤${prefix}Simih2 (1/0)
│🏓⃤${prefix}Autosticker (1/0)
│🏓⃤${prefix}Autorepo (1/0)
│🏓⃤${prefix}Leveling (1/0)
│🏓⃤${prefix}Modonsfw (1/0)
│🏓⃤${prefix}Odelete (1/0)
│🏓⃤${prefix}x9visuunica (1/0)
│🏓⃤${prefix}x9 (1/0)
│🏓⃤${prefix}Limitecomandos
│🏓⃤${prefix}Tempocmd (segundos)
│🏓⃤${prefix}Legenda_imagem (Texto)
│🏓⃤${prefix}Legenda_video (Texto)
│🏓⃤${prefix}Legenda_estrangeiro (Texto)
│🏓⃤${prefix}infobv
│🏓⃤${prefix}Legendabv (Texto)
│🏓⃤${prefix}Legendasaiu (Texto)
│🏓⃤${prefix}So_adm
│🏓⃤${prefix}sairgp
│🏓⃤${prefix}regrasgp
│🏓⃤${prefix}Requestgp -list
│🏓⃤${prefix}Requestgp -a numero
│🏓⃤${prefix}Requestgp -r numero
│🏓⃤${prefix}Fechar-gp
│🏓⃤${prefix}Listanegra (Número)
│🏓⃤${prefix}Tirardalista (Número)
│🏓⃤${prefix}ListanegraG (Número)
│🏓⃤${prefix}TirardalistaG (Número)
│🏓⃤${prefix}Multiprefixo (1/0)
│🏓⃤${prefix}Add_prefixo
│🏓⃤${prefix}Tirar_prefixo
│🏓⃤${prefix}Banghost
│🏓⃤${prefix}Mute (@mencionar)
│🏓⃤${prefix}Desmute (@mencionar)
│🏓⃤${prefix}Add 5511.. (Para-adicionar) 
│🏓⃤${prefix}Reviver (Responder-mensagem)
│🏓⃤${prefix}Kick [@] (Para-remover) 
│🏓⃤${prefix}Ban (Responder-mensagem)
│🏓⃤${prefix}Promover [@] (Ser-admin)
│🏓⃤${prefix}Rebaixar [@] (Rebaixar-adm)
│🏓⃤${prefix}Changegroup (all/adms)
│🏓⃤${prefix}Rmphotogp (Remover ft do gp)
│🏓⃤${prefix}Ephemeral (Desativar ou ativar as  mds temp)
│🏓⃤${prefix}Descgp (Texto)
│🏓⃤${prefix}Nomegp (Nome)
│🏓⃤${prefix}Totag (Mencionar algo)
│🏓⃤${prefix}Grupo (f/a)
│🏓⃤${prefix}ultplv (@)
│🏓⃤${prefix}Status
│🏓⃤${prefix}Limpar (texto-invisível-gp)
│🏓⃤${prefix}Atividades (DO-GRUPO)
│🏓⃤${prefix}Linkgp
│🏓⃤${prefix}Grupoinfo
│🏓⃤${prefix}Blockcmdgp (cmd)
│🏓⃤${prefix}Unblockcmdgp (cmd)
│🏓⃤${prefix}Listbcmdgp
│🏓⃤${prefix}Hidetag (txt) (marcação)
│🏓⃤${prefix}Marcar (marca tds do gp)
│🏓⃤${prefix}Marcar2 (Marca-tds-wa.me)
│🏓⃤${prefix}Anagrama (1/0)
│🏓⃤${prefix}Antipalavra (1/0)
╰═══════════════════ ⪨`;
};

exports.adms = adms;

// MENU DE DONO

const menudono = (prefix, pushname, NickDono, NomeDoBot, isChVip, sender, packname) => {
return `​para configurar o bot use: ${prefix}configurar-bot
╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐌𝐄𝐍𝐔 𝐃𝐎𝐍𝐎⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝
╭══════════════ ⪩
│🏓⃤${prefix}Cortesia24
│🏓⃤${prefix}nuke (arquivar-grupo)
│🏓⃤${prefix}tirar_docnt
│🏓⃤${prefix}limpar_mortos-cnt
│🏓⃤${prefix}criargp (Nome)
│🏓⃤${prefix}divid (ID GRUPO)
│🏓⃤${prefix}cobrar
│🏓⃤${prefix}limpartinder
│🏓⃤${prefix}console
│🏓⃤${prefix}Unbangp
│🏓⃤${prefix}Bangp
│🏓⃤${prefix}totalcmd
│🏓⃤${prefix}dono1 (@)
│🏓⃤${prefix}dono2 (@)
│🏓⃤${prefix}dono3 (@)
│🏓⃤${prefix}dono4 (@)
│🏓⃤${prefix}dono5 (@)
│🏓⃤${prefix}dono6 (@)
│🏓⃤${prefix}Foto-menu (Marcar-img) 
│🏓⃤${prefix}Cmdpremlist
│🏓⃤${prefix}Addcmdprem (cmd)
│🏓⃤${prefix}Delcmdprem (cmd)
│🏓⃤${prefix}Serpremium
│🏓⃤${prefix}Listagp
│🏓⃤${prefix}Antipalavrão (1/0)
│🏓⃤${prefix}Antiligar (1/0)
│🏓⃤${prefix}antipv3 (1/0)
│🏓⃤${prefix}Modoaluguel (1/0)
│🏓⃤${prefix}Fazertm (Texto)
│🏓⃤${prefix}Rgtm
│🏓⃤${prefix}Tirardatm
│🏓⃤${prefix}Listatm
│🏓⃤${prefix}Infocmd_add (cmd/texto) 
│🏓⃤${prefix}Infocmd_del (cmd) 
│🏓⃤${prefix}Visualizarmsg
│🏓⃤${prefix}Botoff (Funcionalidade do bot)
│🏓⃤${prefix}Boton (Funcionalidade do bot)
│🏓⃤${prefix}Verificado-global (Selos)
│🏓⃤${prefix}Audio-menu (Audio do menu)
│🏓⃤${prefix}Addpalavra (palavrão)
│🏓⃤${prefix}Delpalavra (palavrão)
│🏓⃤${prefix}Ativo
│🏓⃤${prefix}Rmpalavra_forca (palavra)
│🏓⃤${prefix}Addpalavras_forca (titulo|tema|dica)
│🏓⃤${prefix}Listbcmdglobal - Lista de cmd block global.
│🏓⃤${prefix}Blockcmdg (comando) - Bloquear comando.
│🏓⃤${prefix}Unblockcmdg (comando) - Desbloquear comando.
│🏓⃤${prefix}Buscarsbcity (@marcar)
│🏓⃤${prefix}Addpix (numero/valor)
│🏓⃤${prefix}Setpix (numero/valor)
│🏓⃤${prefix}Delpix (numero/valor)
│🏓⃤${prefix}Zerarsc (numero)
│🏓⃤${prefix}Gerargf (code)
│🏓⃤${prefix}Delgf (code)
│🏓⃤${prefix}Addrent (558298.../dias)
│🏓⃤${prefix}Tirarrent (dias)
│🏓⃤${prefix}Delrent
│🏓⃤${prefix}Listrent
│🏓⃤${prefix}Lastrent
│🏓⃤${prefix}Codelistrent
│🏓⃤${prefix}Gerarcoderent (556596.../dias)
│🏓⃤${prefix}Delcoderent (código)
│🏓⃤${prefix}Gerarcodecort
│🏓⃤${prefix}Ausente (fale-oq-faz)
│🏓⃤${prefix}Delpremium (@marcar/dias)
│🏓⃤${prefix}Addpremium (@marcar/dias)
│🏓⃤${prefix}Privphotobot (all/cntt/ngm)
│🏓⃤${prefix}Privaddgroup (all/cntt/ngm)
│🏓⃤${prefix}Descriçãogp (digite-algo)
│🏓⃤${prefix}Block [@] (bloq de usar cmds) 
│🏓⃤${prefix}Unblock [@] (desbloquear) 
│🏓⃤${prefix}Setprefix (prefixo-novo)
│🏓⃤${prefix}Bcgp (TM-PRA-PV-MEMBROS)
│🏓⃤${prefix}Addlevel (quantidade)
│🏓⃤${prefix}Tirarlevel (quantidade)
│🏓⃤${prefix}Addxp (quantidade)
│🏓⃤${prefix}Tirarxp (quantidade)
│🏓⃤${prefix}Blocklevellist
│🏓⃤${prefix}Blocklevel (@marcar)
│🏓⃤${prefix}Unblocklevel (@marcar)
│🏓⃤${prefix}Rmlevel (@marcar)
╰═══════════════════ ⪨`;
};

exports.menudono = menudono;

// MENU DE LOGOS 

const menulogos = (prefix, sender) => {
  
  return `​╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐌𝐄𝐍𝐔 𝐋𝐎𝐆𝐎𝐒⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝ 
╭━━━⪩ *LOGOS* ⪨━━━
│🏓⃤${prefix}hackneon [TXT]
│🏓⃤${prefix}fpsmascote [TXT]
│🏓⃤${prefix}equipemascote [TXT]
│🏓⃤${prefix}txtquadrinhos [TXT]
│🏓⃤${prefix}ffavatar [TXT]
│🏓⃤${prefix}mascotegame [TXT]
│🏓⃤${prefix}angelglx [TXT]
│🏓⃤${prefix}gizquadro [TXT]
│🏓⃤${prefix}wingeffect [TXT]
│🏓⃤${prefix}blackpink [TXT]
│🏓⃤${prefix}girlmascote [TXT]
│🏓⃤${prefix}logogame [TXT]
│🏓⃤${prefix}cria [TXT] 
│🏓⃤${prefix}anime1 [TXT]
│🏓⃤${prefix}game [TXT]
│🏓⃤${prefix}ff2 [TXT]
│🏓⃤${prefix}anime2 [TXT]
│🏓⃤${prefix}entardecer [TXT]
│🏓⃤${prefix}dragonredn [TXT]
│🏓⃤${prefix}wolf [TXT]
│🏓⃤${prefix}anime2 [TXT]
│🏓⃤${prefix}cria anime1 [TXT]
│🏓⃤${prefix}game [TXT]
│🏓⃤${prefix}ff1 [TXT]
│🏓⃤${prefix}chufuyu [TXT]
│🏓⃤${prefix}ffgren [TXT]
│🏓⃤${prefix}ffrose [TXT]
│🏓⃤${prefix}entardecer [TXT]
│🏓⃤${prefix}indian [TXT]
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *LOGOS AV* ⪨━━━
│🏓⃤${prefix}glitch [TXT]
│🏓⃤${prefix}write [TXT]
│🏓⃤${prefix}advancedglow [TXT]
│🏓⃤${prefix}typography [TXT]
│🏓⃤${prefix}pixelglitch [TXT]
│🏓⃤${prefix}neonglitch [TXT]
│🏓⃤${prefix}flag [TXT]
│🏓⃤${prefix}flag3d [TXT]
│🏓⃤${prefix}deleting [TXT]
│🏓⃤${prefix}blackpink [TXT]
│🏓⃤${prefix}glowing [TXT]
│🏓⃤${prefix}underwater [TXT]
│🏓⃤${prefix}logomaker [TXT]
│🏓⃤${prefix}cartoon [TXT]
│🏓⃤${prefix}papercut [TXT]
│🏓⃤${prefix}watercolor [TXT]
│🏓⃤${prefix}effectclouds [TXT]
│🏓⃤${prefix}blackpinklogo [TXT]
│🏓⃤${prefix}gradient [TXT]
│🏓⃤${prefix}summerbeach [TXT]
│🏓⃤${prefix}luxurygold [TXT]
│🏓⃤${prefix}multicoloredneon [TXT]
│🏓⃤${prefix}sandsummer [TXT]
│🏓⃤${prefix}galaxywallpaper [TXT]
│🏓⃤${prefix}1917 [TXT]
│🏓⃤${prefix}makingneon [TXT]
│🏓⃤${prefix}royal [TXT]
│🏓⃤${prefix}freecreate [TXT]
│🏓⃤${prefix}galaxy [TXT]
│🏓⃤${prefix}darkgreen [TXT]
│🏓⃤${prefix}lighteffects [TXT] 
│🏓⃤${prefix}dragonball [TXT]
│🏓⃤${prefix}neondevil [TXT]
│🏓⃤${prefix}frozen [TXT]
│🏓⃤${prefix}wooden3d [TXT]
│🏓⃤${prefix}metal3d [TXT]
│🏓⃤${prefix}ligatures [TXT]
│🏓⃤${prefix}3druby [TXT]
│🏓⃤${prefix}sunset [TXT]
│🏓⃤${prefix}cemetery [TXT]
│🏓⃤${prefix}halloween [TXT]
│🏓⃤${prefix}horror [TXT]
│🏓⃤${prefix}blood [TXT]
│🏓⃤${prefix}joker [TXT]
│🏓⃤${prefix}clouds [TXT]
╰━━━━━─「愛」─━━━━━`;
};

exports.menulogos = menulogos;

// MENU DE ALTERAR ÁUDIOS E VÍDEOS

const alteradores = (prefix, sender) => {

return`​╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐀𝐋𝐓𝐄𝐑𝐀𝐃𝐎𝐑𝐄𝐒⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝
╭┤𝐀𝐋𝐓𝐄𝐑𝐀𝐑-𝐕𝐈𝐃𝐄𝐎
│🏓⃤${prefix}Videolento (marca)
│🏓⃤${prefix}Videorapido (marca)
│🏓⃤${prefix}Videocontrario (marca)
╰╦══════════════════ ⪨
╭┤𝐀𝐋𝐓𝐄𝐑𝐀𝐑-𝐀𝐔𝐃𝐈𝐎
│🏓⃤${prefix}Audiolento (marca)
│🏓⃤${prefix}Audiorapido (marca)
│🏓⃤${prefix}Grave (marca)
│🏓⃤${prefix}Grave2 (marca)
│🏓⃤${prefix}Esquilo (marca)
│🏓⃤${prefix}Estourar (marca)
│🏓⃤${prefix}Bass (marca)
│🏓⃤${prefix}Bass2 (marca)
│🏓⃤${prefix}Vozmenino (marca)
╰═══════════════════ ⪨`;
};

exports.alteradores = alteradores;

// MENU Px
const menupx = (prefix, sender) => { 

return `╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐏𝐔𝐗𝐀𝐑-𝐃𝐀𝐃𝐎𝐒⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝
╭══════════════ ⪩
│🏓⃤${prefix}nome (nome)
│🏓⃤${prefix}nome2 (nome)
│🏓⃤${prefix}cpf (numero)
│🏓⃤${prefix}cpf2 (numero)
│🏓⃤${prefix}cpf3 (numero)
│🏓⃤${prefix}cpf4 (numero)
│🏓⃤${prefix}mae (nome)
│🏓⃤${prefix}placa (numero)
╰═══════════════ ⪨`;
};

exports.menupx = menupx;

const menuprem = (prefix, sender) => { 

return `╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐌𝐄𝐍𝐔-𝐏𝐑𝐄𝐌𝐈𝐔𝐌⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝
​╭══════════════ ⪩
│🏓⃤${prefix}ddd (31)
│🏓⃤${prefix}Destrava
│🏓⃤${prefix}Destrava2
│🏓⃤${prefix}Listaddd (Número)
│🏓⃤${prefix}Gerarcpf
│🏓⃤${prefix}Premiumlist
│🏓⃤${prefix}encurtar (Link)
│🏓⃤${prefix}Cuttly (Link)
│🏓⃤${prefix}Bitly (Link)
│🏓⃤${prefix}Celular (Nome)
│🏓⃤${prefix}Scep (Número)
│🏓⃤${prefix}Cotacao (Moeda)
│🏓⃤${prefix}Dinextenso (Valor)
│🏓⃤${prefix}Sip (Número)
│🏓⃤${prefix}Validarcnpj (número)
│🏓⃤${prefix}Igstalk (@usuário)
│🏓⃤${prefix}Validarcpf (número)
╰═════════════ ⪨`;
};

exports.menuprem = menuprem;

// MENU DE BRINCADEIRAS.. 

const brincadeiras = (prefix, sender) => {

return `​╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐌𝐄𝐍𝐔-𝐉𝐎𝐆𝐎𝐒⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝
╭══════════════ ⪩
│🏓⃤${prefix}cassino
│🏓⃤${prefix}Perfil
│🏓⃤${prefix}ship
│🏓⃤${prefix}perfilff
│🏓⃤${prefix}desafio
│🏓⃤${prefix}adivinha (6)
│🏓⃤${prefix}Jogodavelha (@Marcar) 
│🏓⃤${prefix}Anagrama (1/0)
│🏓⃤${prefix}Gartic (1/0)
│🏓⃤${prefix}Whatmusic (1/0)
│🏓⃤${prefix}Quizanimal (1/0)
│🏓⃤${prefix}Enigma (1/0)
│🏓⃤${prefix}R-forca (Letra)
│🏓⃤${prefix}Resetforca (Resetar)
│🏓⃤${prefix}Jogodaforca (Iniciar)
│🏓⃤${prefix}Vab (Você prefere?)
│🏓⃤${prefix}Eununca (Eu nunca, eu já)
│🏓⃤${prefix}Ppt (Pedra/Papel/Tesoura) 
│🏓⃤${prefix}Cassino
│🏓⃤${prefix}meme
│🏓⃤${prefix}Mina (coordenada(s))
│🏓⃤${prefix}Minado (dificuldade)
│🏓⃤${prefix}Minareset (resetar)
│🏓⃤${prefix}Mineshelp (info)
│🏓⃤${prefix}Minatips (dicas)
│🏓⃤${prefix}Akinator (iniciar jogo)
│🏓⃤${prefix}Resetaki (resetar akinator)
╰╦══════════════════ ⪨
╭┤𝐁𝐑𝐈𝐍𝐂𝐀𝐃𝐄𝐈𝐑𝐀𝐒
│🏓⃤${prefix}comer (marca (@))
│🏓⃤${prefix}comer1 (marca (@))
│🏓⃤${prefix}comer2 (marca (@))
│🏓⃤${prefix}comer3 (marca (@))
│🏓⃤${prefix}dar (marca (@))
│🏓⃤${prefix}dar2 (marca (@))
│🏓⃤${prefix}dar3 (marca (@))
│🏓⃤${prefix}comergay (marca (@))
│🏓⃤${prefix}mamar (marca (@))
│🏓⃤${prefix}beijo (marca (@))
│🏓⃤${prefix}Gay (marca (@))
│🏓⃤${prefix}Feio (marca (@))
│🏓⃤${prefix}Corno (marca (@))
│🏓⃤${prefix}Vesgo (marca (@))
│🏓⃤${prefix}Bebado (marca (@))
│🏓⃤${prefix}Gostoso (marca (@))
│🏓⃤${prefix}Gostosa (marca (@))
│🏓⃤${prefix}Beijo (marca (@))
│🏓⃤${prefix}Matar (marca (@))
│🏓⃤${prefix}Tapa (marca (@))
│🏓⃤${prefix}Chute (marca (@))
│🏓⃤${prefix}Dogolpe (marca (@))   
│🏓⃤${prefix}Nazista (marca (@))
│🏓⃤${prefix}personalidade (marca (@))
│🏓⃤${prefix}Chance (fale algo) 
│🏓⃤${prefix}Surubao (Quantidade) 
│🏓⃤${prefix}Casal (Casal do grupo)
│🏓⃤${prefix}Quando (Perguntar)
│🏓⃤${prefix}Mencionar (fale algo)
│🏓⃤${prefix}Death (Nome)
╰╦══════════════════ ⪨
╭┤𝐑𝐀𝐍𝐊
│🏓⃤${prefix}Rankzueiros
│🏓⃤${prefix}Rankgay (5 gays)
│🏓⃤${prefix}Rankgado (5 gados)
│🏓⃤${prefix}Rankcorno (5 cornos)
│🏓⃤${prefix}Rankgostoso (5 gostosos)
│🏓⃤${prefix}Rankgostosa (5 gostosas)
│🏓⃤${prefix}Ranknazista (5 nazistas)
│🏓⃤${prefix}Rankotakus (5 otakus)
│🏓⃤${prefix}ranklixo (5 otakus)
│🏓⃤${prefix}Rankpau (5 pauzudos)
╰═══════════════════ ⪨
╭══════════════ ⪩
│🏓⃤${prefix}saude_geral
│🏓⃤${prefix}saude_exercicios_diarios
│🏓⃤${prefix}saude_alimentacao_saudavel
│🏓⃤${prefix}saude_rotina_sono
│🏓⃤${prefix}saude_hidratacao
│🏓⃤${prefix}saude_mental
│🏓⃤${prefix}saude_condicionamento_fisico
│🏓⃤${prefix}saude_cardiovascular
│🏓⃤${prefix}saude_respiratoria
│🏓⃤${prefix}saude_relaxamento
│🏓⃤${prefix}saude_flexibilidade
│🏓⃤${prefix}saude_ossea
│🏓⃤${prefix}saude_equilibrio_emocional
│🏓⃤${prefix}saude_digestiva
│🏓⃤${prefix}saude_muscular
│🏓⃤${prefix}saude_mental_trabalho
│🏓⃤${prefix}saude_imunologica
│🏓⃤${prefix}saude_energia_fisica
│🏓⃤${prefix}saude_relacionamentos
│🏓⃤${prefix}interesses_casa
│🏓⃤${prefix}interesses_escola
│🏓⃤${prefix}interesses_curso
│🏓⃤${prefix}interesses_rua
│🏓⃤${prefix}interesses_shopping
│🏓⃤${prefix}interesses_parque
│🏓⃤${prefix}interesses_praia
│🏓⃤${prefix}interesses_academia
│🏓⃤${prefix}interesses_trabalho
│🏓⃤${prefix}interesses_cinema
│🏓⃤${prefix}interesses_supermercado
│🏓⃤${prefix}interesses_livraria
│🏓⃤${prefix}interesses_biblioteca
│🏓⃤${prefix}interesses_museu
│🏓⃤${prefix}interesses_restaurante
│🏓⃤${prefix}interesses_festa
│🏓⃤${prefix}interesses_estadio
│🏓⃤${prefix}interesses_aeroporto
│🏓⃤${prefix}interesses_onibus
│🏓⃤${prefix}interesses_hospital
│🏓⃤${prefix}euamor_cachorro
│🏓⃤${prefix}euamor_mae
│🏓⃤${prefix}euamor_pai
│🏓⃤${prefix}euamor_gato
│🏓⃤${prefix}euamor_cavalo
│🏓⃤${prefix}euamor_carro
│🏓⃤${prefix}euamor_natureza
│🏓⃤${prefix}euamor_comida
│🏓⃤${prefix}euamor_viagens
│🏓⃤${prefix}euamor_musica
│🏓⃤${prefix}euamor_futebol
│🏓⃤${prefix}euamor_tecnologia
│🏓⃤${prefix}euamor_esporte
│🏓⃤${prefix}euamor_ciencia
│🏓⃤${prefix}euamor_filmes
│🏓⃤${prefix}euamor_series
│🏓⃤${prefix}euamor_amigos
│🏓⃤${prefix}euamor_livros
│🏓⃤${prefix}euamor_chocolate
│🏓⃤${prefix}euamor_pizza
│🏓⃤${prefix}euamor_sol
│🏓⃤${prefix}euamor_chuva
│🏓⃤${prefix}euamor_festas
│🏓⃤${prefix}euamor_artes
│🏓⃤${prefix}euamor_novelas
│🏓⃤${prefix}euamor_aventura
│🏓⃤${prefix}euamor_teatro
│🏓⃤${prefix}euamor_cozinhar
│🏓⃤${prefix}euamor_animais
│🏓⃤${prefix}euamor_familia
│🏓⃤${prefix}euamor_flor
╰═══════════════════ ⪨`;
};

exports.brincadeiras = brincadeiras;

// MENU RPG DA CITY

const rpgmenu = (prefix, sender) => {

return`​╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐂𝐈𝐓𝐘 𝐎𝐅𝐈𝐂𝐈𝐀𝐋⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝
╭══════════════ ⪩
│🏓⃤${prefix}Lojadecavalos (Loja de cavalos)
│🏓⃤${prefix}Estabulo (Info sobre seus cavalos)
│🏓⃤${prefix}Lojadegalos (Loja de galos)
│🏓⃤${prefix}Galos (Info sobre seus galos)
│🏓⃤${prefix}Galinheiro (Info sobre suas galinhas)
│🏓⃤${prefix}Cruzargg (Cruzar)
│🏓⃤${prefix}Dadoapostado (dado/valor da aposta)
│🏓⃤${prefix}Caracoroa (lado/valor da aposta)
│🏓⃤${prefix}Modorpg (1/0)
│🏓⃤${prefix}Rgcity (Nome)
│🏓⃤${prefix}Saircity (Apagar seus registros) 
│🏓⃤${prefix}Rpglistgp (Lista de registrados)
│🏓⃤${prefix}Meucity (Suas informações)
│🏓⃤${prefix}Minhacarteira (Informações Bancárias)
│🏓⃤${prefix}Rankcity (Os 10 mais ricos da City)
│🏓⃤${prefix}Codelist (Lista de Códigos GiftCards)
│🏓⃤${prefix}Resgatargf (code)
│🏓⃤${prefix}Fazerpix (número/valor)
│🏓⃤${prefix}Chavepix (@marcar o usuário)
│🏓⃤${prefix}Meupix (Sua chave pix na City)
│🏓⃤${prefix}Cassino (valor da aposta)
│🏓⃤${prefix}1xbcbets (valor da aposta)
│🏓⃤${prefix}Assaltar (@marcar)
│🏓⃤${prefix}Minerar
│🏓⃤${prefix}Retirar (Caso você seja preso)
│🏓⃤${prefix}Pescaria
│🏓⃤${prefix}Itenspesca (Comprar os itens)
│🏓⃤${prefix}Trocarbanco 
╰═══════════════════ ⪨`;
};

exports.rpgmenu = rpgmenu;

// MENU DE EFEITOS DE IMAGEM

const efeitos = (prefix, sender) => {

return `​╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐌𝐄𝐍𝐔-𝐃𝐄-𝐄𝐅𝐄𝐈𝐓𝐎𝐒⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝
╭══════════════ ⪩
│🏓⃤${prefix}bolsonaro (marca uma imagem) 
│🏓⃤${prefix}comunismo (marca uma imagem) 
│🏓⃤${prefix}jail (marca uma imagem) 
│🏓⃤${prefix}rip (marca uma imagem) 
│🏓⃤${prefix}pixelate (marca uma imagem) 
│🏓⃤${prefix}lgbt (marca uma imagem) 
╰═══════════════════ ⪨`; 
};

exports.efeitos = efeitos;

// MENU ANIMES 

const animes = (prefix, sender) => {

return `​╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐀𝐍𝐈𝐌𝐄𝐒-𝐄𝐃𝐈𝐓𝐒⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝
╭━━━━━─「愛」─━━━━━
│🏓⃤${prefix}editaleatorio
│🏓⃤${prefix}bleach
│🏓⃤${prefix}narutoedit
│🏓⃤${prefix}jujutsu
│🏓⃤${prefix}hunter
│🏓⃤${prefix}dragonball
│🏓⃤${prefix}demonslayer
│🏓⃤${prefix}chainsaw
╰━━━━━─「愛」─━━━━━
╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐀𝐍𝐈𝐌𝐄𝐒-𝐈𝐌𝐀𝐆𝐄𝐌⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝
╭━━━━━─「愛」─━━━━━
│🏓⃤${prefix}wallpapers4k
│🏓⃤${prefix}wallpaperanimes
│🏓⃤${prefix}wallpaperdark
│🏓⃤${prefix}wallpapervermelho
│🏓⃤${prefix}yuri
│🏓⃤${prefix}erza
│🏓⃤${prefix}elaina
│🏓⃤${prefix}hinata
│🏓⃤${prefix}naruto
│🏓⃤${prefix}minato
│🏓⃤${prefix}yotsuba
│🏓⃤${prefix}shinomiya
│🏓⃤${prefix}yumeko
│🏓⃤${prefix}shizuka
│🏓⃤${prefix}kaga
│🏓⃤${prefix}kotori
│🏓⃤${prefix}mikasa
│🏓⃤${prefix}akiyama
│🏓⃤${prefix}gremory
│🏓⃤${prefix}izuku
│🏓⃤${prefix}shina
│🏓⃤${prefix}kagura
│🏓⃤${prefix}izuku
│🏓⃤${prefix}shina
│🏓⃤${prefix}kagura
│🏓⃤${prefix}shinka
│🏓⃤${prefix}eba
╰━━━━━─「愛」─━━━━━`;
};

exports.animes = animes;

// INFORMAÇÕES DO PROPRIETÁRIO

const infodono = (prefix, NickDono, numerodn, NomeDoBot, sender) => {

return `​👑 *INFORMAÇÕES DO MEU DONO* 👑
╭━━━━━━━━━━━━━━━━
│
│Bot: ${NomeDoBot}
│
│Dono: ${NickDono}
│
│Prefixo: [${prefix}]
│
│Canal:
│https://youtube.com/@sandro_mg1?si=O998UZPhhPnb5YuW
│
│comunidade:
│https://whatsapp.com/channel/0029VarBveB6hENqZSkAM71p
│
│Grupo:
│https://chat.whatsapp.com/ExCKNRkLlFgKZkCZDX2nIA
╰━━━━━━━━━━━━━━━━`;
};

exports.infodono = infodono; 

// MENU FIGURINHAS 

const figurinhas = (prefix, sender) => {

return `​╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐌𝐄𝐍𝐔-𝐅𝐈𝐆𝐔𝐑𝐈𝐍𝐇𝐀𝐒⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝
╭━━━⪩ *FIGURINHAS* ⪨━━━
│🏓⃤${prefix}gura
│🏓⃤${prefix}ttp (Seu texto)
│🏓⃤${prefix}Attp (Seu texto)
│🏓⃤${prefix}Attp1 (Seu texto)
│🏓⃤${prefix}Attp2 (Seu texto)
│🏓⃤${prefix}Attp3 (Seu texto)
│🏓⃤${prefix}Attp4 (Seu texto)
│🏓⃤${prefix}Attp5 (Seu texto)
│🏓⃤${prefix}Attp6 (Seu texto)
│🏓⃤${prefix}Attp7 (Seu texto)
│🏓⃤${prefix}Attp8 (Seu texto)
│🏓⃤${prefix}Attp9 (Seu texto)
│🏓⃤${prefix}Fsticker (Marcar-foto)
│🏓⃤${prefix}Sticker (Marcar-foto)
│🏓⃤${prefix}Toimg (Marcar-sticker)
│🏓⃤${prefix}Togif (Marcar-sticker)
│🏓⃤${prefix}figaleatoria (5)
│🏓⃤${prefix}figuraiva (5)
│🏓⃤${prefix}figuroblox (5)
│🏓⃤${prefix}figuengracada (5)
│🏓⃤${prefix}figuanimais (5)
│🏓⃤${prefix}figudesenho (5)
│🏓⃤${prefix}figubebe (5)
│🏓⃤${prefix}figucoreana (5)
│🏓⃤${prefix}figuflork (5)
╰━━━━━─「愛」─━━━━━`;
};

exports.figurinhas = figurinhas; 

// MENU DOWNLOADS

const downloads = (prefix, sender) => {

return `​╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐌𝐄𝐍𝐔-𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃𝐒⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝
╭━━━⪩ *PESQUISAR* ⪨━━━
│🏓⃤${prefix}videoporn (link-xv)
│🏓⃤${prefix}gimage (anime)
│🏓⃤${prefix}operadora (5531xxxx)
│🏓⃤${prefix}xvsearch (morena)
│🏓⃤${prefix}dorama (link)
│🏓⃤${prefix}pesquisaytb (Sandro bot)
│🏓⃤${prefix}anime (Kimetsu no Yaiba)
│🏓⃤${prefix}googlesearch (Moana)
│🏓⃤${prefix}noticias (Bolsonaro)
│🏓⃤${prefix}chatgpt (ola)
│🏓⃤${prefix}clima (Sao Paulo)
│🏓⃤${prefix}clima2 (Sao Paulo)
│🏓⃤${prefix}letramusic (mc Kevin)
│🏓⃤${prefix}aptoide (Free fire)
│🏓⃤${prefix}aptoidelink (link aptoide)
│🏓⃤${prefix}pesquisa (mc Kevin)
│🏓⃤${prefix}print (https://www.xvideos.com/)
│🏓⃤${prefix}Playstore (free fiee)
│🏓⃤${prefix}Playstore2 (Minecraft)
│🏓⃤${prefix}ytsearch (mc paiva)
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *Download* ⪨━━━
│🏓⃤${prefix}soundcloud (link)
│🏓⃤${prefix}playmix (nome)
│🏓⃤${prefix}play (nome)
│🏓⃤${prefix}play1 (nome)
│🏓⃤${prefix}play2 (nome)
│🏓⃤${prefix}play3 (nome)
│🏓⃤${prefix}play4 (nome)
│🏓⃤${prefix}playvideo (nome)
│🏓⃤${prefix}tiktokaudio (link)
│🏓⃤${prefix}tiktok (link)
│🏓⃤${prefix}tiktok2 (link)
│🏓⃤${prefix}tiktok3 (nome)
│🏓⃤${prefix}ytmp3 (link)
│🏓⃤${prefix}ytmp4 (link)
│🏓⃤${prefix}ytdoc (link)
│🏓⃤${prefix}ytsearch (nome)
│🏓⃤${prefix}spotify (link)
│🏓⃤${prefix}twitteraudio (link)
│🏓⃤${prefix}twittervideo (link)
│🏓⃤${prefix}Instagram (link)
│🏓⃤${prefix}Instagramaudio (link)
╰━━━━━─「愛」─━━━━━`;
};

exports.downloads = downloads;

// MENU PORNO 

const nsfw = (prefix, sender) => {

return `╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐌𝐄𝐍𝐔-+𝟏𝟖⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝
╭━━━⪩ *FOTOS* ⪨━━━
│🏓⃤${prefix}gangbang
│🏓⃤${prefix}hentai
│🏓⃤${prefix}ass
│🏓⃤${prefix}bdsm
│🏓⃤${prefix}cuckold
│🏓⃤${prefix}blowjob
│🏓⃤${prefix}cum
│🏓⃤${prefix}aline
│🏓⃤${prefix}carne
│🏓⃤${prefix}celestino
│🏓⃤${prefix}Rute
│🏓⃤${prefix}polonesa 
│🏓⃤${prefix}nega
│🏓⃤${prefix}nath
│🏓⃤${prefix}meladinha 
│🏓⃤${prefix}princesa
│🏓⃤${prefix}maru 
│🏓⃤${prefix}marina
│🏓⃤${prefix}leticia 
│🏓⃤${prefix}lay
│🏓⃤${prefix}Isa
│🏓⃤${prefix}isadora 
│🏓⃤${prefix}giovanna 
│🏓⃤${prefix}feh
│🏓⃤${prefix}clowniac 
│🏓⃤${prefix}cami 
│🏓⃤${prefix}brenda 
│🏓⃤${prefix}belle 
│🏓⃤${prefix}victoria
│🏓⃤${prefix}aninha 
│🏓⃤${prefix}amicham 
│🏓⃤${prefix}alycia 
│🏓⃤${prefix}alifox 
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *PLAQUINHAS* ⪨━━━
│🏓⃤${prefix}Plaq (SANDRO)
│🏓⃤${prefix}Plaq1 (SANDRO)
│🏓⃤${prefix}Plaq2 (SANDRO)
│🏓⃤${prefix}Plaq3 (SANDRO)
│🏓⃤${prefix}Plaq4 (SANDRO)
│🏓⃤${prefix}Plaq5 (SANDRO)
│🏓⃤${prefix}Plaq6 (SANDRO)
│🏓⃤${prefix}Plaq7 (SANDRO)
│🏓⃤${prefix}Plaq8 (SANDRO)
│🏓⃤${prefix}Plaq9 (SANDRO)
│🏓⃤${prefix}plaq9 (SANDRO)
│🏓⃤${prefix}plaq10 (SANDRO)
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *VIDEO +18* ⪨━━━
│🏓⃤${prefix}amador
│🏓⃤${prefix}porno
│🏓⃤${prefix}egirlvideo
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *only* ⪨━━━
│🏓⃤${prefix}only1
│🏓⃤${prefix}only2
│🏓⃤${prefix}only3
│🏓⃤${prefix}only4
│🏓⃤${prefix}only5
│🏓⃤${prefix}only6
│🏓⃤${prefix}only7
│🏓⃤${prefix}only8
│🏓⃤${prefix}only9
│🏓⃤${prefix}only10
│🏓⃤${prefix}only11
│🏓⃤${prefix}only12
╰━━━━━─「愛」─━━━━━`; 
};

exports.nsfw = nsfw;

// MENU SEM PREFIXO 

const semprefixo = (prefix, sender) => {

return `​⃤𝐒𝐀𝐍𝐃𝐑𝐎 𝐌𝐃 V20⃤`;
};

exports.semprefixo = semprefixo; 

const menulink = (prefix, sender) => {

return `╔♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╗
╠═⪩⟨🏓𝐌𝐄𝐍𝐔-𝐋𝐈𝐍𝐊⟩
╚♡∞*♡♡∞:｡.｡🏓｡.｡:∞♡*♡:∞♡╝
╭━━━⪩ *JOGOS* ⪨━━━
​│🏓⃤${prefix}jogo1
│🏓⃤${prefix}jogo2
│🏓⃤${prefix}jogo3
│🏓⃤${prefix}jogo4
│🏓⃤${prefix}jogo5
│🏓⃤${prefix}jogo6
│🏓⃤${prefix}jogo7
│🏓⃤${prefix}jogo8
│🏓⃤${prefix}jogo9
│🏓⃤${prefix}jogo10
│🏓⃤${prefix}jogo11
│🏓⃤${prefix}jogo12
│🏓⃤${prefix}jogo13
│🏓⃤${prefix}jogo14
│🏓⃤${prefix}jogo15
│🏓⃤${prefix}jogosamp
│🏓⃤${prefix}jogo16
│🏓⃤${prefix}jogo17
│🏓⃤${prefix}jogo18
│🏓⃤${prefix}jogo19
│🏓⃤${prefix}jogo20
│🏓⃤${prefix}jogo21
│🏓⃤${prefix}jogo22
│🏓⃤${prefix}jogo23
│🏓⃤${prefix}jogo24
│🏓⃤${prefix}jogo25
│🏓⃤${prefix}jogo26
│🏓⃤${prefix}jogo27
│🏓⃤${prefix}jogo28
│🏓⃤${prefix}jogo29
│🏓⃤${prefix}jogo30
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *SÉRIES* ⪨━━━
│🏓⃤${prefix}serie1
│🏓⃤${prefix}serie2
│🏓⃤${prefix}serie3
│🏓⃤${prefix}serie4
│🏓⃤${prefix}serie5
│🏓⃤${prefix}serie6
│🏓⃤${prefix}serie7
│🏓⃤${prefix}serie8
│🏓⃤${prefix}serie9
│🏓⃤${prefix}serie10
│🏓⃤${prefix}serie11
│🏓⃤${prefix}serie12
│🏓⃤${prefix}serie13
│🏓⃤${prefix}serie14
│🏓⃤${prefix}serie15
│🏓⃤${prefix}serie16
│🏓⃤${prefix}serie17
│🏓⃤${prefix}serie18
│🏓⃤${prefix}serie19
│🏓⃤${prefix}serie20
│🏓⃤${prefix}serie21
│🏓⃤${prefix}serie22
│🏓⃤${prefix}serie23
│🏓⃤${prefix}serie24
│🏓⃤${prefix}serie25
│🏓⃤${prefix}serie26
│🏓⃤${prefix}serie27
│🏓⃤${prefix}serie28
│🏓⃤${prefix}serie29
│🏓⃤${prefix}serie30
│🏓⃤${prefix}serie31
│🏓⃤${prefix}serie32
│🏓⃤${prefix}serie33
│🏓⃤${prefix}serie34
│🏓⃤${prefix}serie35
│🏓⃤${prefix}serie36
│🏓⃤${prefix}serie37
│🏓⃤${prefix}serie38
│🏓⃤${prefix}serie39
│🏓⃤${prefix}serie40
│🏓⃤${prefix}serie41
│🏓⃤${prefix}serie42
│🏓⃤${prefix}serie43
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *FILMES* ⪨━━━
│🏓⃤${prefix}filme1
│🏓⃤${prefix}filme2
│🏓⃤${prefix}filme3
│🏓⃤${prefix}filme4
│🏓⃤${prefix}filme5
│🏓⃤${prefix}filme6
│🏓⃤${prefix}filme7
│🏓⃤${prefix}filme8
│🏓⃤${prefix}filme9
│🏓⃤${prefix}filme10
│🏓⃤${prefix}filme11
│🏓⃤${prefix}filme12
│🏓⃤${prefix}filme13
│🏓⃤${prefix}filme14
│🏓⃤${prefix}filme15
│🏓⃤${prefix}filme16
│🏓⃤${prefix}filme17
│🏓⃤${prefix}filme18
│🏓⃤${prefix}filme19
│🏓⃤${prefix}filme20
│🏓⃤${prefix}filme21
│🏓⃤${prefix}filme22
│🏓⃤${prefix}filme23
│🏓⃤${prefix}filme24
│🏓⃤${prefix}filme25
│🏓⃤${prefix}filme26
│🏓⃤${prefix}filme27
│🏓⃤${prefix}filme28
│🏓⃤${prefix}filme29
│🏓⃤${prefix}filme30
│🏓⃤${prefix}filme31
│🏓⃤${prefix}filme32
│🏓⃤${prefix}filme33
│🏓⃤${prefix}filme34
│🏓⃤${prefix}filme35
│🏓⃤${prefix}filme36
│🏓⃤${prefix}filme37
│🏓⃤${prefix}filme38
│🏓⃤${prefix}filme39
│🏓⃤${prefix}filme40
│🏓⃤${prefix}filme41
│🏓⃤${prefix}filme42
│🏓⃤${prefix}filme43
│🏓⃤${prefix}filme44
│🏓⃤${prefix}filme45
│🏓⃤${prefix}filme46
│🏓⃤${prefix}filme47
│🏓⃤${prefix}filme48
│🏓⃤${prefix}filme49
│🏓⃤${prefix}filme50
│🏓⃤${prefix}filme51
│🏓⃤${prefix}filme52
│🏓⃤${prefix}filme53
│🏓⃤${prefix}filme54
│🏓⃤${prefix}filme55
╰━━━━━─「愛」─━━━━━
╭━━━⪩ *APPS* ⪨━━━
│🏓⃤${prefix}app1
│🏓⃤${prefix}app2
│🏓⃤${prefix}app3
│🏓⃤${prefix}aap4
│🏓⃤${prefix}app5
│🏓⃤${prefix}app6
│🏓⃤${prefix}app7
│🏓⃤${prefix}app8 
│🏓⃤${prefix}app9
│🏓⃤${prefix}app10
│🏓⃤${prefix}app11
│🏓⃤${prefix}app12
╰━━━━━─「愛」─━━━━━`;
};

exports.menulink = menulink; 