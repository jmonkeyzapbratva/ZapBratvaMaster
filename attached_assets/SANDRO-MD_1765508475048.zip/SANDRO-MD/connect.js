
const baileys = require('@whiskeysockets/baileys');

const {
  default: makeWASocket,
  useMultiFileAuthState,
  makeInMemoryStore,
  DisconnectReason,
  WAGroupMetadata,
  relayWAMessage,
  MediaPathMap,
  mentionedJid,
  processTime,
  MediaType,
  MessageType,
  Presence,
  Mimetype,
  Browsers,
  delay,
  fetchLatestBaileysVersion,
  MessageRetryMap,
  extractGroupMetadata,
  generateWAMessageFromContent,
  proto,
  otherOpts,
  makeCacheableSignalKeyStore
} = baileys;

const { fs, Boom, axios, crypto, util, P, linkfy, request, cheerio, ms, exec, moment, time, hora, date, getBuffer, fetchJson, getBase64, upload, banner2, banner3, colors, getGroupAdmins } = require('./exports.js');

let ativado = false;

// Define 'ran' como um número aleatório
let ran = Math.floor(Math.random() * 1000000); // número aleatório entre 0 e 999999
DLT_FL(ran);

const { menu, anotacao, menudono, adms, menulogos, efeitos, menuprem, brincadeiras, infodono, alteradores, destrava, destrava2, tabela, conselhob, palavrasc, ban, joguinhodavelhajs, joguinhodavelhajs2, nescessario, setting, logoslink, premium, countMessage, sendVideoAsSticker, sendImageAsSticker, sendVideoAsSticker2, sendImageAsSticker2, sotoy, daily, comandos, limitefll, antispam, anotar, getRandom, NodeCache,insert, response } = require('./exports.js');

const { NomeDoBot, NickDono, prefix } = require("./settings/settings.json");

var { fundo1, fundo2 } = require("./settings/links_img.json");

const sleep = async (ms) => {return new Promise(resolve => setTimeout(resolve, ms))};

function DLT_FL(file) {
try { fs.unlinkSync(file) } catch (error) {}
}

const kontol_info2 = console.info;
console.info = function() { 
if(!util.format(...arguments).includes("Closing session: SessionEntry")){ 
return kontol_info2(...arguments); 
}};

const kontol_info1 = console.info;
console.info = function() { 
if(!util.format(...arguments).includes("Removing old closed session: SessionEntry {}")){
return kontol_info1(...arguments);
}};

const msgRetryCounterCache = new NodeCache();

const readline = require("readline");

const pairingCode = process.argv.includes("sim");
const rl = readline.createInterface({input: process.stdin, output: process.stdout,});
const question = (text) => new Promise((resolve) => rl.question(text, resolve));

async function iniciarbluxnexmart() {
var folderUserAuth = "./database/qr-code";

const { state, saveCreds } = await useMultiFileAuthState(folderUserAuth);

const { version, isLatest } = await fetchLatestBaileysVersion();

const bluxnexmart = makeWASocket({
  version,
  auth: state,
  syncFullHistory: true,
  printQRInTerminal: !pairingCode,
  qrTimeout: 180000,
  logger: P({ level: 'silent' }),
  browser: ["Chrome (Linux)", "", ""],
  msgRetryCounterCache,
  connectTimeoutMs: 60000,
  defaultQueryTimeoutMs: 0,
  keepAliveIntervalMs: 10000,
  emitOwnEvents: true,
  fireInitQueries: true,
  generateHighQualityLinkPreview: true,
  syncFullHistory: true,
  markOnlineOnConnect: true,
  patchMessageBeforeSending: (message) => {
  const requiresPatch = !!(message.buttonsMessage || message.listMessage);
    if (requiresPatch) {
      message = {
        viewOnceMessage: {
         message: {messageContextInfo: {
          deviceListMetadataVersion: 2,
          deviceListMetadata: 
          {},
       }, 
       ...message}}}}
   return message;
}
});

const PhoneNumber = require('awesome-phonenumber')

if (pairingCode && !bluxnexmart.authState.creds.registered) {
try {
let number = await question(`${colors.gray("Exemplo do número para realizar a conexão do bot: +55 82 9999-9999. (Coloque do jeito que está no WhatsApp)")}${colors.cyan("\n• Insira no parâmetro o número de telefone que você deseja conectar o bot: ")}`);
number = number.replace(/[^0-9]/g, "");
let code = await bluxnexmart.requestPairingCode(number);
code = code?.match(/.{1,4}/g)?.join("-") || code;
console.log(`${colors.cyan("• Código para conectar o bot e desfrutar de suas imensas funcionalidades: ")}` + colors.white(code));
rl.close();
} catch(error) {
console.error('Falha ao solicitar o código de registro. Por favor, tente novamente.\n', error)
}
}

bluxnexmart.ev.process(async(events) => {
if(events["group-participants.update"]){
try {
var blux2 = events["group-participants.update"];
if(!fs.existsSync(`./database/grupos/activation_gp/${blux2.id}.json`)) return
var jsonGp = JSON.parse(fs.readFileSync(`./database/grupos/activation_gp/${blux2.id}.json`));

if(blux2.participants[0].startsWith(bluxnexmart.user.id.split(':')[0])) return;

try { var grpmdt = await bluxnexmart.groupMetadata(blux2.id) } catch (e) { return }

const isGroup2 = grpmdt.id.endsWith('@g.us');

try {
var GroupMetadata_ = isGroup2 ? await bluxnexmart.groupMetadata(blux2.id): ""} catch (e) {return}

const membros_ = isGroup2 ? GroupMetadata_.participants : '';
const groupAdmins_ = isGroup2 ? getGroupAdmins(membros_) : '';

if(blux2.action == 'add'){
num = blux2.participants[0];
if(nescessario.listanegraG.includes(num)){
await bluxnexmart.sendMessage(GroupMetadata_.id,{text: 'Olha quem deu as cara por aqui, sente o poder do ban...'});
bluxnexmart.groupParticipantsUpdate(GroupMetadata_.id, [blux2.participants[0]], 'remove');
return;
}}
if(blux2.action == 'remove'){
num = blux2.participants[0];
}
if(blux2.action == 'add' && jsonGp[0].listanegra.includes(blux2.participants[0])){
await bluxnexmart.sendMessage(GroupMetadata_.id,{text: 'Olha quem deu as cara por aqui, sente o poder do ban cabaço...'});
bluxnexmart.groupParticipantsUpdate(GroupMetadata_.id, [blux2.participants[0]], 'remove');
}
if(jsonGp[0].antifake && blux2.action === 'add' && !blux2.participants[0].startsWith(55)){
if(jsonGp[0].legenda_estrangeiro != "0") {
await bluxnexmart.sendMessage(GroupMetadata_.id, {text: jsonGp[0].legenda_estrangeiro});
}
setTimeout(async() => {
bluxnexmart.groupParticipantsUpdate(GroupMetadata_.id, [blux2.participants[0]], 'remove');
}, 1000);
}

if(!jsonGp[0].wellcome[1].bemvindo2 && !jsonGp[0].wellcome[0].bemvindo1) return;
try {
var mdata_2 = isGroup2 ? await bluxnexmart.groupMetadata(blux2.id): "";
} catch (e) {
return;
}
const isWelcomed = jsonGp[0].wellcome[0].legendabv != null ? true : false;
const isByed = jsonGp[0].wellcome[0].legendasaiu != 0 ? true : false;
const isWelcomed2 = jsonGp[0].wellcome[1].legendabv != null ? true : false;
const isByed2 = jsonGp[0].wellcome[1].legendasaiu != 0 ? true : false;
const groupDesc = await mdata_2.desc;
if(jsonGp[0].antifake == true && !blux2.participants[0].startsWith(55)) return;
if(jsonGp[0].wellcome[0].bemvindo1 == true){

/////////Push descrição do grupo 
try {
ppimg = await bluxnexmart.profilePictureUrl(blux2.participants[0]);
} catch(e) {
ppimg = 'https://telegra.ph/file/b5427ea4b8701bc47e751.jpg';
}
try {
ppgp = await bluxnexmart.profilePictureUrl(mdata_2.id);
} catch(e) {
ppgp = 'https://telegra.ph/file/b5427ea4b8701bc47e751.jpg';
}
shortpc = await axios.get(`https://tinyurl.com/api-create.php?url=${ppimg}`);

if (blux2.action === 'add') {
let pushname = '@' + blux2.participants[0].split('@')[0];
if (isWelcomed) {
teks = jsonGp[0].wellcome[0].legendabv
.replace('#hora#', time)
.replace('#nomedogp#', mdata_2.subject)
.replace('#numerodele#', pushname)
.replace('#numerobot#', bluxnexmart.user.id)
.replace('#prefixo#', jsonGp[0].multiprefix == true ? jsonGp[0].prefixos[0] : setting.prefix)
.replace('#descrição#', groupDesc);
    } else {
teks = welcome(pushname, mdata_2.subject);
}
let buff = await getBuffer(ppimg);
ran = getRandom('.jpg');
await fs.writeFileSync(ran, buff);
let ranBV = [
        `ao grupo ${encodeURI(mdata_2.subject)}`,
        `O membro ${pushname} chegou quem faltava...`,
        `Leia as regras xuxu.`,
        `E lá vamos nós!.`,
        `Aqui é um Hospício kkk!`,
        `Aqui ninguém é normal kkk`,
        `Gostou de mim me aluga bb`,
        `Não contavam com minha astúcia!`];
bluxnexmart.sendMessage(mdata_2.id, { image: { url: `https://zero-two-apis.com.br/welcome?titulo=BEM%20VINDO%20(A)&nome=${encodeURIComponent(pushname)}&perfil=${shortpc.data}&fundo=${fundo2}&grupo=BEM%20VINDO%20AO%20GRUPO%20${encodeURIComponent(mdata_2.subject)}` },
caption: teks,
mentions: blux2.participants });
DLT_FL(ran);
} else if (blux2.action === 'remove') {
let mem = blux2.participants[0];
let pushname = '@' + mem.split('@')[0];
try {
ppimg = await bluxnexmart.profilePictureUrl(`${mem.split('@')[0]}@c.us`);
    } catch (e) {
ppimg = 'https://telegra.ph/file/b5427ea4b8701bc47e751.jpg'; }
if (isByed) {
teks = jsonGp[0].wellcome[0].legendasaiu
.replace('#hora#', time)
.replace('#nomedogp#', mdata_2.subject)
.replace('#numerodele#', pushname)
.replace('#numerobot#', bluxnexmart.user.id)
.replace('#prefixo#', jsonGp[0].multiprefix == true ? jsonGp[0].prefixos[0] : setting.prefix)
.replace('#descrição#', groupDesc);
    } else {
teks = bye(pushname); }
let buff = await getBuffer(ppimg);
ran = getRandom('.jpg');
fs.writeFileSync(ran, buff);
const ranSI = [
        `ao grupo ${encodeURI(mdata_2.subject)}`,
        `O membro ${pushname} saiu nem pagou a coca..`,
        `nao interagiu e quer ter razão.`,
        `menos um gado `,
        `saiu nem faz falta`,
        `segurança tira ele daqui!`,
        `calma chocolate branco `,
        `é como dizem depois do negão\n aqui voce vai precisar de cadeiras de rodas ` ];
bluxnexmart.sendMessage(mdata_2.id, { image: { url: `https://zero-two-apis.com.br/welcome?titulo=%20SAIU%20GRUPO&nome=${encodeURIComponent(pushname)}&perfil=${shortpc.data}&fundo=${fundo1}&grupo=SAIU%20DO%20GRUPO%20${encodeURIComponent(mdata_2.subject)}` },
caption: teks, mentions: blux2.participants });
DLT_FL(ran);
}
}

if(jsonGp[0].wellcome[1].bemvindo2 == true){
if(blux2.action === 'add') {
if(isWelcomed2) {
teks = jsonGp[0].wellcome[1].legendabv
.replace('#hora#', time)
.replace('#nomedogp#', mdata_2.subject)
.replace('#numerodele#', blux2.participants[0].split('@')[0])
.replace('#numerobot#', bluxnexmart.user.id)
.replace('#prefixo#', jsonGp[0].multiprefix == true ? jsonGp[0].prefixos[0] : setting.prefix)
.replace('#descrição#', groupDesc)
} else {
teks = welcome2(blux2.participants[0].split('@')[0], mdata_2.subject)
}
bluxnexmart.sendMessage(mdata_2.id, {text: teks, mentions: blux2.participants})
} else if(blux2.action === 'remove') {
var mem = blux2.participants[0]

if(isByed2) {
teks = jsonGp[0].wellcome[1].legendasaiu
.replace('#hora#', time)
.replace('#nomedogp#', mdata_2.subject)
.replace('#numerodele#', mem.split('@')[0])
.replace('#numerobot#', bluxnexmart.user.id)
.replace('#prefixo#', jsonGp[0].multiprefix == true ? jsonGp[0].prefixos[0] : setting.prefix)
.replace('#descrição#', groupDesc)
} else {
teks = bye2(mem.split('@')[0])
}
await bluxnexmart.sendMessage(mdata_2.id, {
    image: { url: ppimg }, 
    caption: teks,
    mentions: blux2.participants
});
DLT_FL(ran)
}
}

} catch (e) {
console.log(e)
}
}

if(events["messages.upsert"]) {
var upsert = events["messages.upsert"]
require("./sandro.js")(upsert, bluxnexmart)
}

const colors = require('colors');

if (events["connection.update"]) {
  const update = events["connection.update"];
  var { connection, lastDisconnect, qr, isNewLogin, receivedPendingNotifications } = update;

  if (qr) {
    console.clear(); // Limpa a tela antes

    const linha = colors.brightCyan("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

    console.log(linha);
    console.log(colors.bold.white("🔰 SANDRO MD V22 — CONEXÃO COM WHATSAPP"));
    console.log(linha);

    console.log(colors.cyan("📌 O QUE É ISSO:"));
    console.log(colors.white("Este QR Code serve para conectar seu WhatsApp ao SANDRO MD."));
    console.log(colors.white("Isso permite que o bot envie e receba mensagens automaticamente."));
    
    console.log(linha);
    console.log(colors.cyan("🧭 O QUE FAZER AGORA:"));
    console.log(colors.white("1️⃣ Abra o WhatsApp no seu celular."));
    console.log(colors.white("2️⃣ Toque em ⋮ > Dispositivos conectados > Vincular dispositivo."));
    console.log(colors.white("3️⃣ Escaneie o QR Code que será exibido abaixo."));
    
    console.log(linha);
    console.log(colors.green("🔐 Status: Aguardando leitura do QR Code..."));
    console.log(colors.green("🤖 Bot: Online e pronto para responder comandos."));
    console.log(linha);

// DICAS após 1 segundo
    setTimeout(() => {
      const linhaDica = colors.yellow("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

      console.log("\n" + linhaDica);
      console.log(colors.bold.yellow("💡 DICAS IMPORTANTES"));
      console.log(linhaDica);
      console.log(colors.yellow("🔸 O QR Code expira em cerca de 3 minutos."));
      console.log(colors.yellow("🔸 Se não aparecer, verifique sua conexão com a internet."));
      console.log(colors.yellow("🔸 Você também pode usar o código de pareamento (pairing code)."));
      console.log(linhaDica);
    }, 1000);
  }


const shouldReconnect = new Boom(lastDisconnect?.error)?.output.statusCode

switch (connection) {
case 'close': {
  if (!global.erroMostrado) {
    global.erroMostrado = true;

    let reason = lastDisconnect?.error?.output?.statusCode || 0;

    switch (reason) {
      case 428:
        console.log('[❌] - Conexão encerrada. Irei reconectar automaticamente...');
        break;
      case 401:
        console.log('[⚠️] - Autenticação falhou. QR antigo será apagado...');
        exec("cd database && rm -rf qr-code");
        break;
      case 440:
        console.log('[⚠️] - Sessão em conflito. Outra instância pode estar ativa.');
        break;
      case 503:
        console.log('[❌] - Erro desconhecido ao iniciar o bot.');
        break;
      case 502:
        console.log('[❌] - Sua conexão está instável.');
        break;
      case 408:
        console.log('[⚠️] - Internet fraca. Verifique sua conexão.');
        break;
      case 515:
        // Não mostrar nada
        break;
      default:
        console.log('[⚠️] - Conexão fechada por motivo desconhecido:', reason);
    }

    setTimeout(() => {
      global.erroMostrado = false;
      iniciarbluxnexmart(); // sua função de reinicialização
    }, 3000);
  }
}
break;

case 'connecting': {
    const moment = require('moment-timezone');
    const colors = require('colors');

    const date = moment().tz('America/Sao_Paulo').format('DD/MM/YYYY');
    const time = moment().tz('America/Sao_Paulo').format('HH:mm:ss');

    console.log(colors.yellow(`[BOT] Reconectando / Iniciando - ${date} ${time}`));

    if (!ativado) {
        ativado = true;
        setTimeout(() => {
            console.log(colors.green('Sistema ativado com sucesso'));
        }, 1000);
    }

    break;
}

case 'open':
console.log(banner3.string)
console.log(banner2.string)  
console.log(colors.green(`〔 - _ SANDRO MD V22 _ - CONECTADA COM SUCESSO... 〕`))
await bluxnexmart.sendPresenceUpdate("available")
await bluxnexmart.updateProfileStatus(`Olá meu nome é ${NomeDoBot}  Esse é meu prefix(${prefix})`)
break;

default:
break
}}

if(events["creds.update"]) {await saveCreds()};
require("./sandro.js")(bluxnexmart, folderUserAuth);
})}

iniciarbluxnexmart().catch(async(e) => {console.log(colors.red("• ERROR: "+e))})