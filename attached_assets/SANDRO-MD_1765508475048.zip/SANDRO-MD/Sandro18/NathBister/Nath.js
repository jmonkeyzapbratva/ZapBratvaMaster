var Nath = [
    'https://telegra.ph/file/df153eb2d1785a002de1f.jpg',
    'https://telegra.ph/file/03fb63239a2fa17deeff5.jpg',
    'https://telegra.ph/file/36f95aba5eb2cbe93283c.jpg',
    'https://telegra.ph/file/6c8216741e383cd3c2f52.jpg',
    'https://telegra.ph/file/397df821f2d2572662a21.jpg',
    'https://telegra.ph/file/7acb83917038484c58d51.jpg',
    'https://telegra.ph/file/cae90b2412ead6b17e25f.jpg',
    'https://telegra.ph/file/8d61819f8c633d1fc9d15.jpg',
    'https://telegra.ph/file/dea6aee63ff1afd63ccf5.jpg',
    'https://telegra.ph/file/2a9483bc618d92fb8f42d.jpg',
    'https://telegra.ph/file/50a16876a223987c4e359.jpg',
    'https://telegra.ph/file/22adaaf3c0238e3ab9794.jpg',
    'https://telegra.ph/file/bcc5103ebd41431b72639.jpg',
    'https://telegra.ph/file/f282ec944d38f283aff54.jpg',
    'https://telegra.ph/file/59848ea571a5d9b536a15.jpg',
    'https://telegra.ph/file/4e95a328657a8291713da.jpg',
    'https://telegra.ph/file/18e3bb0c974cf5e3d4854.jpg',
    'https://telegra.ph/file/51ad8c41a4551c40bd4ea.jpg',
    'https://telegra.ph/file/93278956d8b55fb7f0f4f.jpg',
    'https://telegra.ph/file/574f98515782515f97a0e.jpg',
    'https://telegra.ph/file/8839ab3eb82dbfe3cbbe7.jpg',
    'https://telegra.ph/file/bdfc4dca85d80f5b05e25.jpg',
    'https://telegra.ph/file/1e4a89d099809f7615412.jpg'
    ]

exports.Nath = Nath