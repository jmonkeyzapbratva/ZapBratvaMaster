var Lay = [
    'https://telegra.ph/file/114d973ba0166e7e7862b.jpg',
    'https://telegra.ph/file/ff67d6604d9fd5cb652e8.jpg',
    'https://telegra.ph/file/1db49d5901f65f01e5e82.jpg',
    'https://telegra.ph/file/8b7b7ab894f51ef2031e8.jpg',
    'https://telegra.ph/file/cfa81d31d4d3ccfd82e37.jpg',
    'https://telegra.ph/file/72f05ab141158aee0b941.jpg',
    'https://telegra.ph/file/c17d552f1dd0b2b8a1de2.jpg',
    'https://telegra.ph/file/8cba9ea56cc6bab385d3e.jpg',
    'https://telegra.ph/file/17e4494ad9e687e5072a2.jpg',
    'https://telegra.ph/file/8ab73ce7c8e4e5187b2da.jpg',
    'https://telegra.ph/file/fc563dea00512ef0a8133.jpg',
    'https://telegra.ph/file/f8ef54c65efc2bdca902b.jpg',
    'https://telegra.ph/file/60722aa02ae361a54534c.jpg',
    'https://telegra.ph/file/c416f86e921f1679eacc2.jpg',
    'https://telegra.ph/file/e8029ebd659c7bda695f9.jpg',
    'https://telegra.ph/file/b6e9c2c8b48f5c8de12cf.jpg',
    'https://telegra.ph/file/dd1dbf7201ddc36926f85.jpg',
    'https://telegra.ph/file/e2a377fe02aba3e0c0200.jpg',
    'https://telegra.ph/file/ddf4267c0bcde9b23fa86.jpg',
    'https://telegra.ph/file/03c310ae1908528a37ac4.jpg',
    'https://telegra.ph/file/eb6473d2865d7b24fe308.jpg',
    'https://telegra.ph/file/9a9acf386f9f27c37b1e4.jpg',
    'https://telegra.ph/file/192b71f05881471d05e37.jpg',
    'https://telegra.ph/file/a09e984b61a1e6f0c2908.jpg',
    'https://telegra.ph/file/9966a1372f4045fdda81e.jpg'
    ]

exports.Lay = Lay