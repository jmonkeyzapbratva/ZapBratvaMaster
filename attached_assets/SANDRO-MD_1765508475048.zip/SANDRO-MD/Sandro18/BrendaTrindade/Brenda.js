var Brenda = [
    'https://telegra.ph/file/ecbf3788b303a0bb71e76.jpg',
    'https://telegra.ph/file/ba455040b02a31ad56e17.jpg',
    'https://telegra.ph/file/8cdedbc5c138e869ce646.jpg',
    'https://telegra.ph/file/5efaa8b85725c5c218b0f.jpg',
    'https://telegra.ph/file/482e356eaa3987e0b81bc.jpg',
    'https://telegra.ph/file/f91e66de0f4f8d1b388d2.jpg',
    'https://telegra.ph/file/3bce88fb7d539105b395d.jpg',
    'https://telegra.ph/file/a84aac8d828d50b5059c3.jpg',
    'https://telegra.ph/file/e6a2959606863fa016a4c.jpg',
    'https://telegra.ph/file/ff0b6e22ce62ff3b0f24f.jpg',
    'https://telegra.ph/file/29fd3024e6197d4014a18.jpg',
    'https://telegra.ph/file/08d4bd6442078daec9b58.jpg',
    'https://telegra.ph/file/cd1f9b5a85dbbab452ceb.jpg',
    'https://telegra.ph/file/882261491f8f8cffae529.jpg',
    'https://telegra.ph/file/b6729eb07154bc71288a6.jpg',
    'https://telegra.ph/file/7acf5935fdd070028a934.jpg',
    'https://telegra.ph/file/0a1c837c982dc3186bb91.jpg',
    'https://telegra.ph/file/2a00c774eb291116fde69.jpg',
    'https://telegra.ph/file/3e44bd8cde1a1793f46c5.jpg',
    'https://telegra.ph/file/418ceef66281cda92ba86.jpg',
    'https://telegra.ph/file/44eac9720303cbc44ccf5.jpg',
    'https://telegra.ph/file/e92daf6881b0ea9180233.jpg',
    'https://telegra.ph/file/5c9a8d0e31185bfa4619e.jpg',
    'https://telegra.ph/file/4bdbcf6180266d2839701.jpg'
    ]

exports.Brenda = Brenda