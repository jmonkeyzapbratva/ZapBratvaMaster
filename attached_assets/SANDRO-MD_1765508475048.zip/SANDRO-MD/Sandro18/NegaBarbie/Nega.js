var Nega = [
    'https://telegra.ph/file/e30de54a94b7de5f85f69.jpg',
    'https://telegra.ph/file/168a4c658cfa0024cd7bf.jpg',
    'https://telegra.ph/file/1c5fe78842c1ce657c69c.jpg',
    'https://telegra.ph/file/9358002db26330eeb2bf6.jpg',
    'https://telegra.ph/file/e1346420c1e162d939091.jpg',
    'https://telegra.ph/file/a82eb55e045b5b1edef52.jpg',
    'https://telegra.ph/file/42dc1caafe66ea7954302.jpg',
    'https://telegra.ph/file/b486b521bf24c645dd645.jpg',
    'https://telegra.ph/file/c0c87a8198b058411b8e5.jpg',
    'https://telegra.ph/file/26fbbb86fba29e4c1458a.jpg',
    'https://telegra.ph/file/6266c5273c996d4e1ea0d.jpg',
    'https://telegra.ph/file/b8b3d88923c3127683faf.jpg',
    'https://telegra.ph/file/6b076ad4802fed7fa1520.jpg',
    'https://telegra.ph/file/a75a7f1348b5591a763ff.jpg',
    'https://telegra.ph/file/048860f9f9a68702a365e.jpg',
    'https://telegra.ph/file/d41814626eec82aee9b22.jpg',
    'https://telegra.ph/file/7795428453ad54d4434de.jpg',
    'https://telegra.ph/file/c086bf64d73b40eec694f.jpg',
    'https://telegra.ph/file/76ae87d58e530b9d529f3.jpg',
    'https://telegra.ph/file/cdbc5cb4d24dfd1782ccd.jpg'
    ]

exports.Nega = Nega