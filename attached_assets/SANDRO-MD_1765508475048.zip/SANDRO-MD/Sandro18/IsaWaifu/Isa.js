var Isa = [
    'https://telegra.ph/file/cac62a21a4c9548bfcb28.jpg',
    'https://telegra.ph/file/d1fc771770d10507f6563.jpg',
    'https://telegra.ph/file/2a67074548a1a94e2af01.jpg',
    'https://telegra.ph/file/6dec8795ed7b2bdc85db8.jpg',
    'https://telegra.ph/file/f2f511080d413f3b1686e.jpg',
    'https://telegra.ph/file/8577a7e558e12cd54b21c.jpg',
    'https://telegra.ph/file/18c1b2847066f54d0ac17.jpg',
    'https://telegra.ph/file/d1c471c8000d91bf39d07.jpg',
    'https://telegra.ph/file/b20dd787026a22df9944e.jpg',
    'https://telegra.ph/file/c716315e813b6111f2bef.jpg',
    'https://telegra.ph/file/4d276e66d0117cc686f88.jpg',
    'https://telegra.ph/file/9de8d8d9b7c9e119e3da7.jpg',
    'https://telegra.ph/file/f8d44b9216e1494c2315c.jpg',
    'https://telegra.ph/file/f4d5a99c850e0dff51f5d.jpg',
    'https://telegra.ph/file/3bfec8243891b1a94aa16.jpg',
    'https://telegra.ph/file/0dfcd0b16593f00265d15.jpg',
    'https://telegra.ph/file/5e085c182ebee44612c0f.jpg',
    'https://telegra.ph/file/a8e94685c1f8b0a9cd560.jpg',
    'https://telegra.ph/file/1768c70762aa0092f0bf3.jpg',
    'https://telegra.ph/file/3c6371dcaa003bc2df362.jpg',
    'https://telegra.ph/file/fe170900644f53eaebcdb.jpg'
    ]

exports.Isa = Isa