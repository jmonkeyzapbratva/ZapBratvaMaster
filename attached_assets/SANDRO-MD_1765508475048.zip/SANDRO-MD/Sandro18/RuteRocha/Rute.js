var Rute = [
    'https://telegra.ph/file/99eb375854c06567a83a8.jpg',
    'https://telegra.ph/file/66c9b7376e43e36ff48fb.jpg',
    'https://telegra.ph/file/e04ad991ffdfbefd3d2ba.jpg',
    'https://telegra.ph/file/29d4b135c9056b91a9f01.jpg',
    'https://telegra.ph/file/9b15c7d1563d5dba28e52.jpg',
    'https://telegra.ph/file/b2f95a57f6165e59b03b6.jpg',
    'https://telegra.ph/file/1362d120c4a8953b03ef3.jpg',
    'https://telegra.ph/file/53f0149b46497f36b2af7.jpg',
    'https://telegra.ph/file/dd3039cef919ae3f7153f.jpg',
    'https://telegra.ph/file/a353521e9979b94bb3552.jpg',
    'https://telegra.ph/file/4928e8e1fe8f010c1cf8e.jpg',
    'https://telegra.ph/file/6bd38c44cf97fcba15a24.jpg',
    'https://telegra.ph/file/5f32efccd18b85e46846a.jpg',
    'https://telegra.ph/file/75b913cedfedd39397f47.jpg',
    'https://telegra.ph/file/e1e393f1449b9c7753dbc.jpg',
    'https://telegra.ph/file/b58f5a326b07e983faa80.jpg',
    'https://telegra.ph/file/295655da9ac01282fc847.jpg',
    'https://telegra.ph/file/939b4e6738ff8a4f4aae1.jpg',
    'https://telegra.ph/file/809d1718b6b0bfb6e24e5.jpg',
    'https://telegra.ph/file/f87991ae187deaa901c3b.jpg',
    'https://telegra.ph/file/c415165ad0cfa8ba924bf.jpg',
    'https://telegra.ph/file/e4f4f75dd934af151c9b2.jpg',
    'https://telegra.ph/file/49c26139836dcfc08c8b2.jpg',
    'https://telegra.ph/file/81f1300abd84823c6c6a6.jpg',
    'https://telegra.ph/file/e87a3a6049634fa173ee0.jpg'
    ]

exports.Rute = Rute