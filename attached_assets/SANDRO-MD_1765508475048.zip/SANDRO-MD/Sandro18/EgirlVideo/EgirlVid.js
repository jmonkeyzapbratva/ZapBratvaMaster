var EgirlVid = [
    'https://telegra.ph/file/8cdbf8147875452e9c5ed.mp4',
    'https://telegra.ph/file/44d57ce199c987893aca8.mp4',
    'https://telegra.ph/file/387fbd05b8adf3f7030d5.mp4',
    'https://telegra.ph/file/d191fae228a1b87452155.mp4',
    'https://telegra.ph/file/7c6c00052d55734e3dc62.mp4',
    'https://telegra.ph/file/b623bd46166e215587a1d.mp4',
    'https://telegra.ph/file/a9d33ad7370a5cb6d4106.mp4',
    'https://telegra.ph/file/7f8f36e71499725956481.mp4',
    'https://telegra.ph/file/dda18a4d447888113ce3b.mp4',
    'https://telegra.ph/file/bf6d9f2b57767c4ea5676.mp4',
    'https://telegra.ph/file/9910198d88f66c0365d68.mp4',
    'https://telegra.ph/file/2f7e24150bc84bf31af3a.mp4',
    'https://telegra.ph/file/72a44792aaf92be8f1e85.mp4',
    'https://telegra.ph/file/40c24e67897c0b1c449de.mp4',
    'https://telegra.ph/file/99ec1f5558e82a3be8563.mp4'
    ]

exports.EgirlVid = EgirlVid